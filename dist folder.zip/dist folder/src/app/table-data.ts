export const calcColumns = [
  {
      'columnDef': 'dealer',
      'displayText': 'dealer code'
  },
  {
      'columnDef': 'sales_history',
      'displayText': 'sales history'
  },
  {
      'columnDef': 'sales_outlook',
      'displayText': 'sales outlook'
  },
{


    'columnDef': 'sales_rate',
    'displayText': 'sales rate'
},
{

  'columnDef': 'inventory',
    'displayText': 'inventory'
},
{

  'columnDef': 'transit_time_adjustment',
    'displayText': 'transit time adjustment'
},
{
  'columnDef': 'earned_allocation',
    'displayText': 'earned allocation'
},
{


  'columnDef': 'imageLink',
  'displayText': ' '
}];

  /*,
  {
      'columnDef': 'deviation_vol',
      'displayText': 'deviations'
  },
  {
      'columnDef': 'target_vol',
      'displayText': 'amount'
  },
  {
      'columnDef': 'suggested_vol',
      'displayText': 'available orders'
  },
  {
      'columnDef': 'issue_category',
      'displayText': 'issue category'
  },
  {
      'columnDef': 'issue_descption',
      'displayText': 'issue description'
  }
];*/



export const clusterDealerColumns = [
{
    'columnDef': 'area',
    'displayText': 'area'
},
{
    'columnDef': 'dealer',
    'displayText': 'dealer'
},
{
    'columnDef': 'comm_number',
    'displayText': 'comm number'
},
{
    'columnDef': 'trim',
    'displayText': 'trim'
},
{
    'columnDef': 'sale_model_code',
    'displayText': 'sale model code'
},
{
    'columnDef': 'ext_color_code',
    'displayText': 'exterior/interior'
},
/*{
  'columnDef': 'int_color_code',
    'displayText': 'int color code'
},*/
{
    'columnDef': 'factory_options',
    'displayText': 'factory options'
},
{
    'columnDef': 'mdo_options',
    'displayText': 'mdo options'

}

];


export const calculationTable = [
  {
      'columnDef': 'CLUSTER',
      'displayText': 'CLUSTER'
  },
  {
      'columnDef': 'ACCOUNT_CODE',
      'displayText': 'ACCOUNT CODE'
  },
  {
      'columnDef': 'account_code',
      'displayText': 'account code'
  },
  {
      'columnDef': 'sales_model_code',
      'displayText': 'sales model code'
  },
  {
      'columnDef': 'color',
      'displayText': 'exterior / interior'
  },
  {
      'columnDef': 'factory_options',
      'displayText': 'factory options'
  },
  {
      'columnDef': 'mdo_options',
      'displayText': 'market delivery options'
  },
  {
      'columnDef': 'order_vol',
      'displayText': 'volume'
  }
];
//*
