import {
  Component,
  OnInit,
  Input,
  Output,
  ViewChild,
  EventEmitter,
  TemplateRef,
  AfterContentInit,
  ElementRef,
} from '@angular/core';
import { MatTable, MatSort, MatTableDataSource, MatPaginator, MatPaginatorIntl } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { isObservable, Observable, Subject } from 'rxjs';
import { DataTableColumn } from '../models/data-table';
import { DataService } from '../data.service';

export interface DataFromParent {
  columns: DataTableColumn[];
  rows: any[];
  expandRows?: any[];
  options?: {
    pageSize: number;
  };
}
interface ExpandableRow {
  template: TemplateRef<any>;
}

const selectColumn: DataTableColumn = {
  columnDef: 'select',
  displayText: 'Accepted',
};

export class CustomPaginator extends MatPaginatorIntl {
  constructor() {
    super();
  }
  getRangeLabel = (page: number, pageSize: number, length: number) => {
    if (length === 0 || pageSize === 0) { return `0 of ${length}`; }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    const endIndex = startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
    return `${startIndex + 1} - ${endIndex} of ${length}`;
  }
}

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss'],
  providers: [{
    provide: MatPaginatorIntl,
    useClass: CustomPaginator
  }]
})
export class DataTableComponent implements OnInit, AfterContentInit {


  @Input() id = `dt-${Math.random()}`;  // set an ID for the table
  @Input() tableWidth: number;  // set Table width
  @Input() dataFromParent: DataFromParent | Observable<DataFromParent>;  // observable w/ columns and table row data
  @Input() enablePagination = false;
  @Input() pageSize = 10; // the options for changing pagination
  @Input() pageSizeOptions: number[] = [5, 10, 20]; // the options for changing pagination
  @Input() enableSelection = false; // enables selection for table
  @Input() showSelectionColumn = false; // shows 1st selection column
  @Input() multiSelect = false; // enables multiselection
  @Input() footer: object = null;  // renders footer cells if footer data provided
  @Input() expandRows: ExpandableRow[] = []; // requires at least a template
  @Input() toggleColumns = false;
  @Input() stickyHeader = false;
  @Input() tableFilter: Subject<string>;
  @Input() hideHeader = false;
  imgobj = false;

  // emit events for different table actions
  @Output() tableRendered: EventEmitter<any> = new EventEmitter();
  @Output() rowSelected: EventEmitter<any> = new EventEmitter();
  @Output() rowClicked: EventEmitter<any> = new EventEmitter();

  displayedColumns: string[] = []; // array of columnDefs, determines which columns are displayed
  dataSource: any;  // the end data source used by the table
  selection: SelectionModel<any>; // maintains selected rows for table
  expandedElement: any; // currently open expanded row
  columns: DataTableColumn[]; // used to generate table columns in html, also contains column level logic (filtering etc)
  columnsPositionsArray: any[];
  colorcolumn :boolean = false;
  constructor(private service : DataService) { }

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatTable, { read: ElementRef }) materialTable: MatTable<any>;

  ngAfterContentInit() {
    this.tableRendered.emit(this);
  }

  ngOnInit() {
debugger;
    this.imgobj = this.service.imgFlag;

    this.colorcolumn = this.service.colorFlag;
    if (this.tableFilter) { // if provided, set up subscription to filter
      this.tableFilter.subscribe(latestFilterValue => {
        this.applyFilter(latestFilterValue);
      });
    }
    this.selection = new SelectionModel(this.multiSelect, []); // define selection model
    if (isObservable(this.dataFromParent)) { // data source can be observable
      this.dataFromParent.subscribe((tableData: DataFromParent) => {
        this.setColumns(tableData.columns);
        if (tableData.expandRows) {
          this.setRows(tableData.rows, tableData.expandRows);
        } else {
          this.setRows(tableData.rows);
        }
        if (tableData.options) {
          this.setOptions(tableData.options);
        }

      });
    } else { // or can be passed directly as normal object { columns; rows; }
      this.setColumns(this.dataFromParent.columns);
      this.setRows(this.dataFromParent.rows);
      if (this.dataFromParent.options) {
        this.setOptions(this.dataFromParent.options);
      }
    }
  }

  setOptions(tableData: any) {
    for (const key in tableData.options) {
      if (tableData.options.hasOwnProperty(key)) {
        this[key] = tableData.options[key];
      }
    }
  }

  setRows(rows: any[], expandRows?: any[]) {
    const tableRows = [];
    rows.forEach((element, index) => {
      if (expandRows && expandRows.length) {
        tableRows.push(
          element,
          Object.assign(
            {
              detailRow: true,                        // indicates to template this is detail row
              element: element,                       // if === "expandedElement" this expand row will show
            },
            expandRows[index],                   // adds additional properties defined in parent component
          )
        );
      }
      if (element.accepted_flag) { // selects elements if accepted
        this.selection.select(element);
      }
    });

    this.dataSource = new MatTableDataSource(tableRows.length ? tableRows : rows);
    this.dataSource.sort = this.sort;
    if (this.enablePagination) {
      this.dataSource.paginator = this.paginator;
    }
  }

  isExpansionDetailRow(i: number, row: Object) {
    return row.hasOwnProperty('detailRow');
  }

  toggleColumn(columnToToggle: any, toggleAdjacent?: boolean): void {
    // search displayedColumns to see if column is showing
    const isDisplayed = this.displayedColumns.findIndex(column => {
      return column === columnToToggle.columnDef;
    });
    if (isDisplayed !== -1) {  // column found, remove from displayedColumns
      this.displayedColumns.splice(isDisplayed, 1);
      if (toggleAdjacent) { // already removed main column, now same index is "next"
        this.displayedColumns.splice(isDisplayed, 1);
      }
    } else { // find its original location on columnsPositionsArray and run insert logic
      let columnToShowIndex;
      const columnToShow = this.columnsPositionsArray.find((column, index) => {
        if (column.columnDef === columnToToggle.columnDef) { columnToShowIndex = index; }
        return column.columnDef === columnToToggle.columnDef;
      });
      const columnsToCompare = this.columnsPositionsArray.filter(column => {
        return this.displayedColumns.includes(column.columnDef);
      });
      toggleAdjacent ?
        columnsToCompare.push(columnToShow, this.columnsPositionsArray[columnToShowIndex + 1]) :
        columnsToCompare.push(columnToShow);
      columnsToCompare.sort((a, b) => a.position - b.position);
      this.displayedColumns = columnsToCompare.map(column => column.columnDef);
    }
  }

  setColumns(columns: DataTableColumn[]) {
    this.columns = columns;
    this.displayedColumns = [];
    columns.forEach(column => {
      this.displayedColumns.push(column.columnDef);
    });
    if (this.showSelectionColumn) {
      this.displayedColumns.push(selectColumn.columnDef);
    }
    // if toggleColumns
    // Make Copy of this.columns = columnsPositionsArray
    // for every column, add "position" attribute to index
    // position is how table will make sure columns stay in correct order
    if (this.toggleColumns) {
      this.columnsPositionsArray = this.columns.slice(0);
      this.columnsPositionsArray = this.columnsPositionsArray.map((column: any, index: number) => {
        const newObj = Object.assign({}, column); // create new object else it will have reference and affect this.columns objects
        newObj.position = index;
        return newObj;
      });
    }
  }

  onRowClick(evt?: any, rowData?: object, index?: number) {
    this.rowClicked.emit([rowData, index]);

    if (evt.target.nodeName === 'TD') { // prevent expanding if not actually clicking <td> element

      if (this.expandRows && this.expandRows.length !== undefined) { // if a template is provided
        this.expandedElement = this.expandedElement !== rowData ? rowData : null;
      }

      if (this.enableSelection) {
        // can toggle selection
        this.toggleRow(rowData, index);
      }

    }

  }

  toggleRow(row: any, index?: number) {
    this.selection.toggle(row);
    this.rowSelected.emit(
      {
        rows: this.dataSource.data,
        row: row,
        selection: {
          quantity: this.dataSource.data.length,
          selected: this.selection.selected.length
        },
        childIndex: index
      }
    ); // always emit what row was selected
  }

  cellFormatter(value: any, format: string) {
    switch (format) {
      case 'percent':
        return `${value}%`;
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  isTemplateRef(val: any) {
    return val instanceof TemplateRef;
  }

  loadpopup()
  {

  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    if (!this.isAllSelected()) { // select all rows
      this.dataSource.data.forEach((row, index) => {
        if (!this.selection.isSelected(row)) {
          this.toggleRow(row, index);
        }
      });
    } else { // clear selection
      this.selection.clear();
      this.dataSource.data.forEach((row, index) => this.rowSelected.emit(
        {
          rows: this.dataSource.data,
          selection: {
            quantity: this.dataSource.data.length,
            selected: this.selection.selected.length
          },
          childIndex: index
        }
      ));
    }
  }

}
