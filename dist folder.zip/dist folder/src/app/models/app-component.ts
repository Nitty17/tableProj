export interface MdoOption {
    option_code: string;
    option_description: string;
    msrp: number;
}
export interface VWColorCode {
    ext_color_code?: string;
    int_color_code?: string;
    ext_color_img?: string;
    int_color_img?: string;
}