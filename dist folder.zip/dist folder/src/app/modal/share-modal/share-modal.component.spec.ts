import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShareModelComponent } from './share-modal.component';

describe('ModelComponent', () => {
  let component: ShareModelComponent;
  let fixture: ComponentFixture<ShareModelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShareModelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShareModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
