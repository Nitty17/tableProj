import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'share-model',
  templateUrl: './share-modal.html',
  styleUrls: ['./share-modal.component.scss']
})
export class ShareModelComponent implements OnInit {

  constructor(private modalService: NgbModal) {}
data : any = [];
@Input() mdoData  : any;
mdoColl :any = [];
leftMdoColl : any =[];
rightMdoColl : any=[];
flag = false;

  open(content) {
    debugger;
    const modalRef = this.modalService.open(content, { size: 'lg' });
  }


  ngOnInit() {
  }



}
