import { Component, OnInit } from '@angular/core';
import { CodegenComponentFactoryResolver } from '@angular/core/src/linker/component_factory_resolver';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-info-modal',
  templateUrl: './info-modal.component.html',
  styleUrls: ['./info-modal.component.scss']
})
export class InfoModalComponent implements OnInit {

  constructor(private modalService: NgbModal) {}

  ngOnInit() {
    debugger;
  }

  detailsList = ["Dealer Code", "Sales]history","Sales outlook",
                "Sales rate","Inventory","Transit Time Adjustment",
                "Earned Allocation","Adjusted Day Supply","Area",
                "Area Bulk","Carline","Cluster","Cluster Bulk","Day Supply Allocation",
                "Dealers(same as dealer code)","Ending Day Supply","Ending Inventory",
                "Excluded Inventory","Final  Carline supply","Ideal Mix",
                "Initial Day Supply","Region","Region Bulk","Sales Share Allocation",
                "Transit Time Adjustment","Trim Short","Trim Short Allocation"];

                open(content) {
                  debugger;
                  const modalRef = this.modalService.open(content, { size: 'lg' });


                }



}
