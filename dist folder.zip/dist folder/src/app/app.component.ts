import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
} from '@angular/core';

import { Observable } from 'rxjs';
//import * as XLSX from 'xlsx';

import { DataFromParent } from './data-table/data-table.component';
import { calcColumns, clusterDealerColumns } from './table-data';
import { DataTableComponent } from './data-table/data-table.component';
import { DataTableColumn } from './models/data-table';
import { OrderValidationApiService, ColorDescriptionService, ColorCodesService } from './shared/services';
import { DataService } from './data.service';
import { MatDialog} from '@angular/material';
import {ModelComponent} from './model/model.component'
import { InfoModalComponent } from './modal/info-modal/info-modal.component';
import { ShareModelComponent } from './modal/share-modal/share-modal.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [OrderValidationApiService]
})

export class AppComponent implements OnInit {
  lockStatus :any[] = [{name:'2019 Atlas',lock : false},
                     {name: '2019 Arteon',lock : true},
                     {name :'2019 Beetle',lock : true},
                     {name:'2019 Golf',lock : true},
                     {name:'2019 Pasaat',lock : true},
                     {name:'2019 Tiguan',lock : true}];
  lockFlag : boolean = true;
  unlockFlag : boolean = true;
  lockImg = "";
  unlockImg = "";

  showModalOne = false;
  constructor(private modalService: NgbModal,
    private services: DataService,
    private colorDescriptionService: ColorDescriptionService,
    private colorCodesService: ColorCodesService,
    private dialog: MatDialog) { }

  exportModal() {
    // let exportRef = this.dialog.open(ExcelExportModalComponent, { width: '600px', data: this.data });
    // exportRef.afterClosed().subscribe((data) => {
     // this.functionToDownloadExcelFile();
    //})
  }

  openInfoModal(){
    let infoModal = this.dialog.open(InfoModalComponent, {
      width:'600px',
      data:[{option_code: 1, option_description: "item1"},{option_code:2,  option_description: "item2"}]
    });
  }

  exportToExcel(){
    let shareModal = this.dialog.open(ShareModelComponent, {
      width:'600px',
      data:[{option_code: 1, option_description: "item1"},{option_code:2,  option_description: "item2"}]
    });
  }

  toggleModalOne() {
    debugger;
  let dialogRef = this.dialog.open(InfoModalComponent, {
      width:'60%', height:'60%'

    });

   // const modalRef = this.modalService.open(InfoModalComponent);


  }

  carlines: any[] = [];

  //deColumns: any[] = deviationColumns;
  calculationColumns : any[] = calcColumns;
  clusterColumns : any[] = clusterDealerColumns;
  deDisplayColumns: any;
  deDataSubscriber: any;
  calcSubscriber: any;
  deFooter: DataTableColumn;
  deData: any;
  calcDataFull : any;
  calcRowData: any[];

  clusterDataFull : any;
  clusterRowData: any[];

  deDataSubscription: any;
  deviationData: Observable<DataFromParent>;
  pageSize: number;
  selectedCarline: any;
  selectedTrim: any;
  carlineTrim: any;
  formattedCarlineTrim: any;

  //mcColumns: DataTableColumn[] = massChangeColumns;
  mcDisplayColumns: any;
  mcDataSubscriber: any;
  mcData: any;
  mcRowData: any[];
  mcDataSubscription: any;
  massChangeData: Observable<DataFromParent>;


  //@ViewChild('deviationTable') deviationTable: DataTableComponent;
//@ViewChild('deviationTableTemplate') deviationTableTemplate: TemplateRef<any>;

 // @ViewChild('massChangeTable') massChangeTable: DataTableComponent;
 // @ViewChild('massChangeTableTemplate') massChangeTableTemplate: TemplateRef<any>;

 // @ViewChild('optionsTemplate')
//  private optionsTemplate: TemplateRef<any>;

  //@ViewChild('colorPreviewTemplate')
 // private colorPreviewTemplate: TemplateRef<any>;

  changeIcon(data)
  {
      this.lockStatus.forEach((item) =>{if(!item.lock) item.lock = true;});
      data.lock = false;
  }

  ngOnInit(): void {





    this.services.loadCalculationData().subscribe((data: any) => {
      console.log('data is ', data);

      this.services.imgFlag = false;
      debugger;
      this.services.colorFlag = false;
      this.calcRowData = data.distribution_allocation_review.claclulation_result_details.dealer_mix;


     //this.services.clusterData = data.mdo_template.available_mdo_list;
      this.calcDataFull = new Observable(sub => {
        this.calcSubscriber = sub;
        sub.next({ columns: this.calculationColumns, rows: this.calcRowData });
      });


    });



    this.services.loadCalculationData().subscribe((data: any) => {
      console.log('data is ', data);

      this.services.imgFlag = false;
      debugger;


      this.clusterRowData =  data.distribution_allocation_review.optimization_result_details;



      this.services.colorFlag = true;

      this.clusterDataFull = new Observable(sub => {
        this.calcSubscriber = sub;
        sub.next({ columns: this.clusterColumns, rows: this.clusterRowData });
      });
    });
  }





}
