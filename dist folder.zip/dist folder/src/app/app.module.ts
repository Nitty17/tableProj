// Angular components
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatCheckboxModule, MatSortModule } from '@angular/material';
import { MatRadioModule } from '@angular/material/radio';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatMenuModule } from '@angular/material';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialogModule } from '@angular/material/dialog';
import {ShareModelComponent} from './modal/share-modal/share-modal.component'
// our components
import { AppComponent } from './app.component';
import { DataTableComponent } from './data-table/data-table.component';
//import { ColorSwatchDialogComponent } from './shared/services';

// our pipes
import { FormatAs, FormatRegion } from './shared/pipes';
import { FormatOptionPipe } from './shared/pipes';
import { ModelComponent } from './model/model.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { IconBoxComponent } from './icon-box/icon-box.component';
import { InfoModalComponent } from './modal/info-modal/info-modal.component';

@NgModule({
  declarations: [
    AppComponent,
    DataTableComponent,
    FormatAs,
    FormatRegion,
    FormatOptionPipe,
    ModelComponent,
    IconBoxComponent,
    InfoModalComponent,
    ShareModelComponent
    //ColorSwatchDialogComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    MatTableModule,
    MatPaginatorModule,
    BrowserAnimationsModule,
    FlexLayoutModule,
    MatCheckboxModule,
    MatRadioModule,
    FormsModule,
    MatIconModule,
    MatFormFieldModule,
    MatSelectModule,
    MatMenuModule,
    MatTooltipModule,
    MatDialogModule,
    NgbModule,
    MatSortModule

  ],
  //entryComponents: [ColorSwatchDialogComponent],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [InfoModalComponent, ShareModelComponent]
})
export class AppModule { }
