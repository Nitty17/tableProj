import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../data.service';

@Component({
  selector: 'app-model',
  templateUrl: './model.component.html',
  styleUrls: ['./model.component.scss']
})
export class ModelComponent implements OnInit {

  constructor(private modalService: NgbModal, private dataservice : DataService) {}
data : any = [];
@Input() mdoData  : any;
mdoColl :any = [];
leftMdoColl : any =[];
rightMdoColl : any=[];
flag = false;

  open(content) {
    debugger;
    const modalRef = this.modalService.open(content, { size: 'lg' });

    this.leftMdoColl = [];
    this.rightMdoColl = [];
   var tempColl = this.dataservice.mdoOptions;




var i =0;
    for( i = 0 ;i < tempColl[0].mdo_list.length/2 ; i++  )
    {
     // if(i == this.mdoData)
    //  this.mdoColl = tempColl[0].mdo_list;
      this.leftMdoColl.push(tempColl[0].mdo_list[i]);
    }

    for(var j = i ;j <  tempColl[0].mdo_list.length ; j++  )
    {
     // if(i == this.mdoData)
    //  this.mdoColl = tempColl[0].mdo_list;
      this.rightMdoColl.push( tempColl[0].mdo_list[i]);
    }

  }


  ngOnInit() {
  }



}
