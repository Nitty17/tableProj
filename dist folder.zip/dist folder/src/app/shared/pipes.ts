import {
  Pipe,
  PipeTransform
} from '@angular/core';

@Pipe({ name: 'formatOption' })
export class FormatOptionPipe implements PipeTransform {
  formatString(items: any, previewAmount: number) {
    let previewString = '';
    if (items && items.length) {
      const arrayOfCodes = [];
      for (let i = 0; i < items.length || i < previewAmount; i++) {
        arrayOfCodes.push(items[i].option_code);
      }
      const displayedOptions = arrayOfCodes.slice(0, previewAmount);
      displayedOptions.forEach((option, index) => {
        if (!index) {
          previewString += `${option}`;
        } else {
          previewString += ` | ${option}`;
        }
      });
    }
    return previewString;
  }
  transform(items: any, format: string): string {
    // should change to switch / if else if we get more options than mdo / fo
    return format === 'mdo' ? this.formatString(items, 3) : this.formatString(items, 2);
  }
}

@Pipe({ name: 'formatAs' })
export class FormatAs implements PipeTransform {
  transform(item: any, format: string): string {
    switch (format) {
      case 'percent':
        return `${item}%`;
    }
  }
}

@Pipe({ name: 'formatRegion' })
export class FormatRegion implements PipeTransform {
  transform(item: any, region: string): string {
    return `${item} ${region}`;
  }
}
