export const analyticsColumns = [
    {
        'columnDef': 'expandArrow',
        'displayText': ''
    },
    {
        'columnDef': 'trim_short',
        'displayText': 'trim short'
    },
    {
        'columnDef': 'ideal_mix',
        'displayText': 'ideal mix',
        'format': 'percent',
        'grouped': true
    },
    {
        'columnDef': 'dealer_suggested_orders',
        'displayText': 'suggested orders'
    },
    {
        'columnDef': 'sales_rate',
        'displayText': 'sales rate',
        'grouped': true
    },
    {
        'columnDef': 'dealer_day_supply',
        'displayText': 'my days supply'
    },
    {
        'columnDef': 'region_day_supply',
        'displayText': 'days supply'
    },
    {
        'columnDef': 'area_day_supply',
        'displayText': 'days supply'
    },
    {
        'columnDef': 'cluster_day_supply',
        'displayText': 'days supply'
    },
    {
        'columnDef': 'dealer_turn_rate',
        'displayText': 'my turn rate',
        'format': 'percent',
        'grouped': true
    },
    {
        'columnDef': 'region_turn_rate',
        'displayText': 'turn rate',
        'format': 'percent',
        'grouped': true
    },
    {
        'columnDef': 'area_turn_rate',
        'displayText': 'turn rate',
        'format': 'percent',
        'grouped': true
    },
    {
        'columnDef': 'cluster_turn_rate',
        'displayText': 'turn rate',
        'format': 'percent',
        'grouped': true
    },
    {
        'columnDef': 'dealer_speed_of_sales',
        'displayText': 'my speed of sales'
    },
    {
        'columnDef': 'region_speed_of_sales',
        'displayText': 'speed of sales'
    },
    {
        'columnDef': 'area_speed_of_sales',
        'displayText': 'speed of sales'
    },
    {
        'columnDef': 'cluster_speed_of_sales',
        'displayText': 'speed of sales'
    },
    {
        'columnDef': 'dealer_aging_stock',
        'displayText': 'my aging stock',
        'format': 'percent',
        'grouped': true
    },
    {
        'columnDef': 'region_aging_stock',
        'displayText': 'aging stock',
        'format': 'percent',
        'grouped': true
    },
    {
        'columnDef': 'area_aging_stock',
        'displayText': 'aging stock',
        'format': 'percent',
        'grouped': true
    },
    {
        'columnDef': 'cluster_aging_stock',
        'displayText': 'aging stock',
        'format': 'percent',
        'grouped': true
    }
];

export const suggestedOrdersColumns = [
    {
        columnDef: 'trim_short',
        displayText: 'trim short',
    },
    {
        columnDef: 'sales_model_desc',
        displayText: 'sales model description',
    },
    {
        columnDef: 'colorPreviewTemplate',
        displayText: 'exterior & interior',
    },
    {
        columnDef: 'foPreviewTemplate',
        displayText: 'factory options',
    },
    {
        columnDef: 'mdoPreviewTemplate',
        displayText: 'market delivery options',
    },
    {
        columnDef: 'allocated_qty',
        displayText: 'quantity',
    },
    {
        columnDef: 'accepted_qty',
        displayText: 'accepted',
    },
    {
        columnDef: 'rejected_qty',
        displayText: 'rejected',
    },
    {
        columnDef: 'edit',
        displayText: '',
    },
];

export const soChildTableColumns = [
    {
        columnDef: 'comm_num',
        displayText: 'commission #',
    },
    {
        columnDef: 'location',
        displayText: 'location',
    },
    {
        columnDef: 'status',
        displayText: 'status',
    },
    {
        columnDef: 'eta',
        displayText: 'eta',
    },
    {
        columnDef: 'mdo_options',
        displayText: 'mdo options',
    },
];
