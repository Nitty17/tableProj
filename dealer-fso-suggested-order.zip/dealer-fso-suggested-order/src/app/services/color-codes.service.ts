

export class ColorCodesService {

  private static urlBase = 'https://www.vw.com/content/dam/vwcom/colorSwatches/';

  constructor() {
    console.log('ColorCodesService - constructor');
  }

  static generateImageUrl = (year: number, carlineName: string, colorCode: string) => {
    const carlineKeyword = carlineName.toLowerCase().replace(' ', '-');
    return ColorCodesService.urlBase + year + '/' + carlineKeyword + '/' + colorCode + '.png';
  }

}
