import { ColorCodesService } from './color-codes.service';

export class ChartOptionsService {

  static getBarChartOptions(chartId: string, chartHeight: number, dataName: string, dataLabels: string[], dataValues: number[], totalAllocation: number, isThreeColumnTile: boolean) {

    const showGraphBottomNumbers = false;
    const chartGraphicalPadding = showGraphBottomNumbers ? 96 : 50;

    // Try to make each bar 26px vertical size. Subtract chartGraphicalPadding from chartSize due to padding around graphical part.
    let barHeightPrct = Math.round(26 / ((chartHeight - chartGraphicalPadding) / dataValues.length) * 100);
    barHeightPrct = Math.min(barHeightPrct, 80);  // Limit to max of 80 percent
    // console.log('getBarChartOptions - barHeightPrct: ' + barHeightPrct);

    // Leave room for dataLabels on outside end of bars, so adjust xAxis max a little higher
    let xAxisMax = 0;
    if (isThreeColumnTile) {
      // Give more space on right end
      xAxisMax = Math.max(...dataValues) * 1.45;
    } else {
      // Give less space on right end
      xAxisMax = Math.max(...dataValues) * 1.25;
    }
    // Round up to nearest 10
    xAxisMax = (Math.round(xAxisMax / 10) + 1) * 10;
    // xAxisMax = (Math.round(xAxisMax / 50) + 1) * 50;
    // console.log('ZZZ', dataValues, Math.max(...dataValues), xAxisMax);

    // Longer text at end of bars seems to need bigger offset
    let dataLabelsOffsetX = 13;
    if (Math.max(...dataValues) > 999) {
      dataLabelsOffsetX = 17;
    } else if (Math.max(...dataValues) > 99) {
      dataLabelsOffsetX = 14;
    }

    const options = {
      chart: {
        id: chartId,
        height: chartHeight,
        type: 'bar',
        // fontFamily: 'Book'
      },
      colors: ['#0d4266'],
      plotOptions: {
        bar: {
          horizontal: true,
          barHeight: barHeightPrct + '%', // '75%', // '70%'
          dataLabels: {
            position: 'top',
          }
        },
      },
      dataLabels: {
        offsetX: dataLabelsOffsetX, // 13, // -7,
        textAnchor: 'start',
        style: {
          fontFamily: 'Book',
          fontSize: '10px',
          colors: ['#000000']
        },
        formatter: function (val, opts) {
          // opts = {seriesIndex, dataPointIndex, w}
          // console.log('formatter', val, opts);
          const percent = Math.round(val / totalAllocation * 100);
          return percent + ' % | ' + val;
        },
      },
      stroke: {
        // width: 1,
        // colors: ['#fff']
      },
      series: [
        {
          name: dataName,
          data: dataValues
        }
      ],
      xaxis: {
        categories: dataLabels,
        axisBorder: {
          show: showGraphBottomNumbers ? true : false
        },
        axisTicks: {
          show: showGraphBottomNumbers ? true : false
        },
        labels: {
          show: showGraphBottomNumbers ? true : false
        },
        title: {
          // text: dataName,
        },
        max: xAxisMax
      },
      yaxis: {
        show: true,
        // labels: {
        //   show: false
        //   // formatter: function(val) {
        //   //   return '<b>' + val + '</b>';
        //   // }
        // },
        axisBorder: {
          show: true
        },
        // axisTicks: {
        //   show: false
        // }
        labels: {
          show: false,
          // style: {
          //   fontFamily: 'Book',
          //   fontSize: '10px'
          // },
          // formatter: function(val) {
          //   // Convert '[P12] TOWING PACKAGE' to 'TOWING PACKAGE'
          //   let str = val;
          //   if (val.length > 0 && val[0] === '[') {
          //     str = val.split('] ')[1];
          //   }
          //   return str;
          // }
        }
      },
      tooltip: {
        x: {
          formatter: function(val) {
            // Convert '[P12] TOWING PACKAGE' to 'P12 - TOWING PACKAGE'
            let str = val;
            if (val.length > 0 && val[0] === '[') {
              str = val.split('] ')[0].slice(1) + ' - ' + val.split('] ')[1];
            }
            return str;
          }
        },
        y: {
          formatter: function(val) {
            const percent = Math.round(val / totalAllocation * 100);
            return val + ' (' + percent + '%)';
          },
        }
      },
      fill: {
        opacity: 1
      },
      legend: {
        show: false
        // position: 'top',
        // horizontalAlign: 'left',
        // offsetX: 40
      },
      grid: {
        yaxis: {
          lines: {
            show: false
          }
        }
      }
    };

    return options;
  }




  static getColorsStackedBarChartOptions(chartId: string, chartHeight: number, extColorMixArray: any[], modelYear: number, carlineDesc: string, intColorMixVolumeFieldName: string) {

    const extColors = [];
    const intColors = [];
    extColorMixArray.forEach(extColorObj => {
      extColors.push({
        code: extColorObj.ext_color_code,
        desc: extColorObj.ext_color_desc,
        img: ColorCodesService.generateImageUrl(modelYear, carlineDesc, extColorObj.ext_color_code)
      });
      extColorObj.int_color_mix.forEach(intColorMixObj => {
        const existingIntColor = intColors.find((item => {
          return item.code === intColorMixObj.int_color_code;
        }));
        if (!existingIntColor) {
          intColors.push({
            code: intColorMixObj.int_color_code,
            desc: intColorMixObj.int_color_desc,
            img: ColorCodesService.generateImageUrl(modelYear, carlineDesc, intColorMixObj.int_color_code)
          });
        }
      });
    });
    // console.log('extColors:', extColors);
    // console.log('intColors:', intColors);

    const extColorNames = [];
    extColors.forEach(extColorObj => {
      extColorNames.push(extColorObj.desc);
    });
    // console.log('extColorNames:', extColorNames);

    const intColorImages = [];
    intColors.forEach(intColorObj => {
      intColorImages.push(intColorObj.img);
    });
    // console.log('intColorImages:', intColorImages);

    const seriesArray = [];
    intColors.forEach(intColor => {
      // Build array of volume values for an interior color across all ext colors,
      // like [75, 0, 24, 0, 195, 72, 14]
      const dataArray = [];
      extColorMixArray.forEach(extColorObj => {
        let foundValue = 0;
        extColorObj.int_color_mix.forEach(intColorMixObj => {
          if (intColorMixObj.int_color_code === intColor.code) {
            // foundValue = intColorMixObj.allocation_vol;
            foundValue = intColorMixObj[intColorMixVolumeFieldName];
          }
        });
        dataArray.push(foundValue);
      });
      seriesArray.push({
        name: intColor.desc,
        data: dataArray
      });
    });
    // console.log('seriesArray:', seriesArray);

    // Subtract 55 from chartSize due to padding around graphical part
    const gridHeight = chartHeight - 55;
    // Try to make each bar 26px vertical size
    let barHeightPrct = Math.round(26 / (gridHeight / extColorNames.length) * 100);
    barHeightPrct = Math.min(barHeightPrct, 80);  // Limit to max of 80 percent
    // console.log('getColorsStackedBarChartOptions - barHeightPrct: ' + barHeightPrct);

    const bgImageSize = 100;
    const bgPatternWidth = bgImageSize / 2;
    const bgImageOffsetX = -(bgImageSize / 4);

    const bgPatternHeight = gridHeight / extColorNames.length;
    const bgImageOffsetY = -((bgImageSize - bgPatternHeight) / 2);

    const options = {
      chart: {
        id: chartId,
        height: chartHeight, // 243
        type: 'bar',
        stacked: true,
        stackType: '100%',
        events: {
          mounted: updateImagePatterns,
          updated: updateImagePatterns
        }
      },
      colors: ['#000000'],
      plotOptions: {
        bar: {
          horizontal: true,
          barHeight: barHeightPrct + '%',  // '70%',
        },
      },
      stroke: {
        width: 1,
        colors: ['#fff']
      },
      series: seriesArray,
      // series: [
      //   {
      //     name: 'SHETLAND V-TEX LEATHERETTE',
      //     data: [75, 0, 24, 0, 195, 72, 14]
      //   }, {
      //     name: 'TITAN BLACK V-TEX',
      //     data: [5, 50, 40, 95, 65, 168, 108]
      //   }, {
      //     name: 'TITAN BLACK CLOTH',
      //     data: [45, 0, 0, 0, 0, 0, 0]
      //   }, {
      //     name: 'GOLDEN OAK & BLACK TWO-TONE',
      //     data: [0, 0, 16, 0, 0, 0, 28]
      //   }
      // ],
      // title: {
      //   text: '100% Stacked Bar'
      // },
      xaxis: {
        categories: extColorNames,
        axisBorder: {
          show: false
        },
        axisTicks: {
          show: false
        },
        labels: {
          show: false
        }
      },
      yaxis: {
        show: false,
        labels: {
          show: false
          // formatter: function(val) {
          //   return '<b>' + val + '</b>';
          // }
        },
        axisBorder: {
          show: false
        },
        axisTicks: {
          show: false
        }
      },
      fill: {
        opacity: 1,
        type: 'image',
        image: {
          src: intColorImages,
          width: 75,
          height: 75
        }
      },
      legend: {
        show: false
        // position: 'top',
        // horizontalAlign: 'left',
        // offsetX: 40
      },
      tooltip: {
        marker: {
          show: false
        },
        x: {
          formatter: function(value, { series, seriesIndex, dataPointIndex, w }) {
            // console.log(series, seriesIndex, dataPointIndex, w, w.globals.seriesTotals[seriesIndex]);
            const extImgUrl = extColors[dataPointIndex].img;
            const extCode = extColors[dataPointIndex].code;
            return '<img src="' + extImgUrl + '" width="18" height="18" style="margin-left:4px;margin-right:2px;"> ' + extCode + ' - ' + value;
          }
        },
        y: {
          title: {
            formatter: function(value, { series, seriesIndex, dataPointIndex, w }) {
              // console.log(series, seriesIndex, dataPointIndex, w, w.globals.seriesTotals[seriesIndex]);
              const intImgUrl = intColors[seriesIndex].img;
              const intCode = intColors[seriesIndex].code;
              return '<img src="' + intImgUrl + '" width="18" height="18" style="margin-right:4px"> ' + intCode + ' - ' + value;
            }
          }
        }
      }
    };

    function updateImagePatterns(chartContext, config) {
      // console.log('updateImagePatterns', chartContext, config);
      // Tweak image patterns after chart has loaded, so we do not see any "seams" between rows of repeated image
      const node = config.globals.dom.elGraphical.node as SVGGElement;
      let defs: SVGDefsElement;
      for (let i = 0; i < node.children.length; i++) {
        if (node.children[i].tagName === 'defs') {
          defs = node.children[i] as SVGDefsElement;
          break;
        }
      }
      for (let i = 0; i < defs.children.length; i++) {
        if (defs.children[i].tagName === 'pattern') {
          const pattern = defs.children[i] as SVGPatternElement;
          // Set width and height of pattern box to be half of image size
          pattern.setAttribute('width', bgPatternWidth + 'px');
          pattern.setAttribute('height', bgPatternHeight + 'px');
          // Set x and y of image, to shift left and up, so center of image now in middle of parent
          pattern.firstElementChild.setAttribute('width', bgImageSize + 'px');
          pattern.firstElementChild.setAttribute('height', bgImageSize + 'px');
          pattern.firstElementChild.setAttribute('x', '' + bgImageOffsetX);
          pattern.firstElementChild.setAttribute('y', '' + bgImageOffsetY);
        }
      }
    }

    return options;
  }

}
