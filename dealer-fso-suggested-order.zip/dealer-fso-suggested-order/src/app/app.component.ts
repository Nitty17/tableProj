import {
  Component,
  OnInit,
  ViewChild,
  ViewChildren,
  QueryList,
  TemplateRef,
} from '@angular/core';
import { FormBuilder } from '@angular/forms';

import { Observable, BehaviorSubject, Subject } from 'rxjs';
import * as XLSX from 'xlsx';
import { MatMenuTrigger } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';

import { DataFromParent } from './data-table/data-table.component';
import { analyticsColumns, suggestedOrdersColumns } from './table-data';
import { FsoApiService, ColorDescriptionService } from './shared/services';
import { DataTableComponent } from './data-table/data-table.component';
import { DataTableColumn } from './models/data-table';
import { VWDialogComponent } from './shared/form-dialog.component';

import { ChartOptionsService } from './services/chart-options.service.js';
import { ColorCodesService } from './services/color-codes.service.js';

declare var ApexCharts: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [FsoApiService,]
})
export class AppComponent implements OnInit {

  constructor(
    private services: FsoApiService,
    private colorDescriptionsService: ColorDescriptionService,
    private fb: FormBuilder,
    public dialog: MatDialog) { }

  regionCode: string;
  clusterId: string;
  areaCode: string;
  dealerCode: string;

  filteredAnalyticsColumns: DataTableColumn[] | any[];
  analyticsDataSubscriber: any;
  analyticsFooter: any; // passed as an Input to analytics table to render in <tfoot> element
  analyticsData: any;
  analyticsRowData: any[];  // keeping a copy of untouched rows for rerendering purposes - ex comparisonGroupChange
  toggleableAnalyticsColumns: DataTableColumn[];  // columns available to toggle visible in analytics table

  soColumns: DataTableColumn[] = suggestedOrdersColumns;
  suggestedOrderRows: any[];
  suggestedOrderData: Subject<DataFromParent>;

  soTableFilter = new Subject();
  loadedModelYear: number;
  loadedCarlineName: string;
  soTableHelpContent: string;
  trims: any[];
  analyticsExpandRowTemplates: any[];
  analyticsColumnsToToggle: any[] = []; // used to update child analytics table columns when updates to parent table trigger rerender
  mdo_options_all: any[];
  factory_options_all: any[];
  // forms
  suggestedOrderForm = this.fb.group({
    // carline: [0],
    comparisonGroup: ['region'],
    search: ['']
  });


  jsonChartDataMain: any;
  jsonChartDataTrims: any;

  trimChartTotalVolume = 0;

  mainChartTrimNames = [];
  mainChartDrivetrainNames = [];
  mainChartTransmissionNames = [];
  mainChartExtColors = [];

  subChartFactoryOptionsNames = [];
  subChartDrivetrainNames = [];
  subChartTransmissionNames = [];
  subChartExtColors = [];

  carlineList = [] as { year: number, desc: string, code: string }[];
  selectedCarline = null as { year: number, desc: string, code: string };

  chartDetailList = ['Drivetrain', 'Transmission'];
  selectedChartDetail = this.chartDetailList[0];

  chartTrimList = [] as string[];
  selectedChartTrim = null as string;


  trendingAnalyticsLinkUrl = '';


  // Add event emitter here for submitting changes
  // @Output

  @ViewChildren(DataTableComponent) childTableTpls: QueryList<DataTableComponent>;

  @ViewChild('analyticsTable') analyticsTable: DataTableComponent;
  @ViewChild('soTable') soTable: DataTableComponent;
  @ViewChild(MatMenuTrigger) analyticsMenuTrigger: MatMenuTrigger;

  @ViewChild('editRowTemplate')
  private editRowTemplate: TemplateRef<any>;

  @ViewChild('optionsTemplate')
  private optionsTemplate: TemplateRef<any>;

  @ViewChild('colorPreviewTemplate')
  private colorPreviewTemplate: TemplateRef<any>;

  @ViewChild('analyticsDetailsTableTemplate')
  private analyticsDetailsTableTemplate: TemplateRef<any>;

  // subscribe to data source and setup / format data to be passed to grids
  ngOnInit(): void {
    this.soTableFilter.next(''); // intialize table filter value

    this.suggestedOrderForm.valueChanges.subscribe(d => {
      console.log('form changed ', d);
    });

    // Get list of carlines first, then set selected carline as first in list and use that to fetch table data
    this.services.getCarlines().subscribe((data: any) => {
      this.carlineList = data.carlines.map((carlineObj) => {
        return {
          year: carlineObj.model_year,
          desc: carlineObj.carline_desc,
          code: carlineObj.carline_code
        };
      });
      this.selectedCarline = this.carlineList[0];

      // Now fetch table data (and then charts data)
      this.getDataForTables();
    });
  }

  getDataForTables() {
    this.services.getTableData(this.selectedCarline.year, this.selectedCarline.code).subscribe((data: any) => {
      if (data.ordering_analytics) {
        // separate footer data from trim short mix array
        const [analyticsRowData, analyticsFooter] =
          (({ trim_short_mix, ...others }) => ([trim_short_mix, { ...others }]))(data.ordering_analytics.analytics_details);
        this.trims = analyticsRowData;
        this.regionCode = data.ordering_analytics.region_code;
        this.clusterId = data.ordering_analytics.cluster_id;
        this.areaCode = data.ordering_analytics.area_code;
        this.dealerCode = data.ordering_analytics.dealer_code;
        const columns = this.appendRegions(analyticsColumns);
        this.filteredAnalyticsColumns = this.filterByComparisonGroup(columns);
        this.toggleableAnalyticsColumns = this.setToggleableColumns(this.filteredAnalyticsColumns);
        this.analyticsFooter = analyticsFooter;
        // set "trim_short" key value so there is a label in the footer
        this.analyticsFooter['trim_short'] = `All ${analyticsFooter.model_year} ${analyticsFooter.carline_name}`;
        this.analyticsRowData = analyticsRowData;
        this.analyticsExpandRowTemplates = this.setAnalyticsExpandRows();
        this.analyticsData = new Observable(sub => {
          this.analyticsDataSubscriber = sub;
          sub.next({ columns: this.filteredAnalyticsColumns, rows: this.analyticsRowData, expandRows: this.analyticsExpandRowTemplates });
        });
      } else if (data.fso_suggested_orders) {
        this.factory_options_all = data.fso_suggested_orders.factory_options;
        this.mdo_options_all = data.fso_suggested_orders.mdo_options;
        if (data.fso_suggested_orders.dealer_fso_suggested_orders_help_content) {
          this.soTableHelpContent = data.fso_suggested_orders.dealer_fso_suggested_orders_help_content.help_content;
        }
        this.setSuggestedOrdersData(data.fso_suggested_orders.order_details);

        // Now fetch charts data
        setTimeout(() => {
          this.getDataForCharts();
        }, 1000);
      }
    });
  }

  // open edit dialog for suggested orders row
  openDialog(index: number, formattedData: any): void {
    const dialogRef = this.dialog.open(VWDialogComponent, {
      data: {
        rowIndex: index,
        formattedData: formattedData,
        mdoOptions: this.mdo_options_all,
        factoryOptions: this.factory_options_all
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  // formats data to be passed to suggested orders table
  // ex. defines custom templates that are passed to table to be rendered
  setSuggestedOrdersData(rows: any) {
    const tableRows = rows.map((row: any, index: number) => {
      this.loadedModelYear = this.analyticsFooter.model_year;
      this.loadedCarlineName = this.analyticsFooter.carline_name;
      const formDialogData = {
        ...row,
        selected_colors: {
          value: `${row.ext_color_code},${row.int_color_code}`,
          extColorDescription: this.colorDescriptionsService.getColorByCode('ext', row.ext_color_code).ext_color_description,
          intColorDescription: this.colorDescriptionsService.getColorByCode('int', row.int_color_code).int_color_description,
          extColorUrl: ColorCodesService.generateImageUrl(this.loadedModelYear, this.loadedCarlineName, row.ext_color_code),
          intColorUrl: ColorCodesService.generateImageUrl(this.loadedModelYear, this.loadedCarlineName, row.int_color_code)
        },
        quantity: row.allocated_qty,
        rejected: row.rejected_qty,
      };

      formDialogData['colorPreviewTemplate'] = {
        template: this.colorPreviewTemplate,
        context: {
          colors: {
            exteriorDescription: formDialogData['selected_colors'].extColorDescription,
            interiorDescription: formDialogData['selected_colors'].intColorDescription,
            exteriorCode: row.ext_color_code,
            interiorCode: row.int_color_code,
          },
          urls: {
            extColorUrl: formDialogData['selected_colors'].extColorUrl,
            intColorUrl: formDialogData['selected_colors'].intColorUrl
          }
        }
      };

      const optionsReducer = (accumulator: any, currentValue: any, optionIndex: number, arr: any[]) => {
        if (currentValue !== undefined) {
          const isNotLast = optionIndex !== arr.length - 1;
          return accumulator + `${currentValue.option_code} - ${currentValue.option_description}${isNotLast ? ', ' : ''}`;
        }
      };

      const mdoOptionsArray = row.mdo_options.includes(',') ? row.mdo_options.split(',') : [row.mdo_options];
      const mdoOptionsDescriptions = mdoOptionsArray.map((option: any) => {
        return this.services.getOptionsDescription(this.mdo_options_all, option);
      });
      const mdoOptionsHoverPreview = mdoOptionsDescriptions.reduce(optionsReducer, '');
      formDialogData['mdoPreviewTemplate'] = {
        template: this.optionsTemplate,
        context: {
          previewLimit: 3,
          options: {
            preview: mdoOptionsHoverPreview || '',
            codes: mdoOptionsArray.length ? mdoOptionsArray : [],
          },
          tableRowIndex: index,
        }
      };

      let factoryOptionsArray;
      if (row.factory_options && row.factory_options.includes(',')) {
        factoryOptionsArray = row.factory_options.includes(',') ? row.factory_options.split(',') : [];
      } else if (row.factory_options.length) {
        factoryOptionsArray = [row.factory_options];
      } else {
        factoryOptionsArray = [];
      }

      const factoryOptionsDescriptions = factoryOptionsArray.map((option: any) => {
        return this.services.getOptionsDescription(this.factory_options_all, option);
      });
      const factoryOptionsHoverPreview = factoryOptionsDescriptions.reduce(optionsReducer, '');
      formDialogData['foPreviewTemplate'] = {
        template: this.optionsTemplate,
        context: {
          previewLimit: 2,
          options: {
            preview: factoryOptionsHoverPreview || '',
            codes: factoryOptionsArray.length ? factoryOptionsArray : [],
          },
          tableRowIndex: index,
        }
      };

      formDialogData['available_colors'] = row.available_colors.map(colors => {  // the array of options the user can select from
        return {
          value: `${colors.ext_color_code},${colors.int_color_code}`,
          extColorDescription: this.colorDescriptionsService.getColorByCode('ext', colors.ext_color_code).ext_color_description,
          intColorDescription: this.colorDescriptionsService.getColorByCode('int', colors.int_color_code).int_color_description,
          extColorUrl: ColorCodesService.generateImageUrl(this.loadedModelYear, this.loadedCarlineName, colors.ext_color_code),
          intColorUrl: ColorCodesService.generateImageUrl(this.loadedModelYear, this.loadedCarlineName, colors.int_color_code),
        };
      });

      formDialogData['edit'] = {
        template: this.editRowTemplate,
        context: {
          available_colors: row.available_colors.map(colors => {  // the array of options the user can select from
            return {
              value: `${colors.ext_color_code}_${colors.int_color_code}`,
              extColorUrl: ColorCodesService.generateImageUrl(this.loadedModelYear, this.loadedCarlineName, colors.ext_color_code),
              intColorUrl: ColorCodesService.generateImageUrl(this.loadedModelYear, this.loadedCarlineName, colors.int_color_code),
            };
          }),
          onClick: this.openDialog.bind(this, index, { ...formDialogData })
        },
      };
      return formDialogData;
    });

    if (this.suggestedOrderData) {  // update data (triggers view rerender)
      this.suggestedOrderData.next({ columns: this.soColumns, rows: tableRows });
    } else {  // define subject
      this.suggestedOrderData = new BehaviorSubject({
        columns: this.soColumns,
        rows: tableRows
      });
    }
  }

  // updates suggested orders table based on text search
  soApplyFilter(newValue) {
    this.soTableFilter.next(newValue);
  }

  // removes 1st 4 columns, expand row column, and comparison group columns "region", "cluster", "area" as toggleable
  setToggleableColumns(items: any) {
    return items.filter((item: any) => {
      return !item.columnDef.includes('region') &&
        !item.columnDef.includes('cluster') &&
        !item.columnDef.includes('area') &&
        !item.columnDef.includes('trim_short') &&
        !item.columnDef.includes('ideal_mix') &&
        !item.columnDef.includes('suggested_orders') &&
        !item.columnDef.includes('sales_rate') &&
        !item.columnDef.includes('expandArrow') &&
        !item.columnDef.includes('expandArrowHidden');
    }).map(item => ({ ...item, checked: true }));
  }

  // toggles analytics table column(s) & updates array used by child tables for toggling columns to match parent analytics table
  toggleAnalyticsColumn(column: any) {
    // updates analyticsColumnsToToggle array (columns in array will be toggled hidden when child tables are rendered)
    const shouldRemoveColumn = this.analyticsColumnsToToggle.findIndex(toToggleColumn => {
      return toToggleColumn.columnDef === column.columnDef;
    });
    shouldRemoveColumn !== -1 ? this.analyticsColumnsToToggle.splice(shouldRemoveColumn, 1) : this.analyticsColumnsToToggle.push(column);
    this.analyticsTable.toggleColumn(column, true); // toggle column and adjacent column
  }

  // toggle (off) any columns in array on render
  childTableRendered(table: any) {
    if (this.analyticsColumnsToToggle.length) {
      this.analyticsColumnsToToggle.forEach((column: any) => {
        table.toggleColumn(column, true); // toggle column and adjacent column
      });
    }
  }

  // adds headerFormat option to desired columns
  // passes value for "region" "cluster" or "area" comparison groups
  appendRegions(cols: DataTableColumn[]): DataTableColumn[] {
    return cols.map((col: any) => {
      const appendVal = col.columnDef.includes('region') || col.columnDef.includes('cluster') || col.columnDef.includes('area');
      if (appendVal) {
        col['headerFormat'] = this.getComparisonGroupValue();
      }
      return col;
    });
  }

  // creates the expandRows array passed to datatable
  setAnalyticsExpandRows() {
    return this.analyticsRowData.map((detail: any, index: number) => {
      // make copy of parent table columns
      // the column headers will update when comparison group is changed because they reference the same object
      const detailColumns = this.filteredAnalyticsColumns.slice(0);
      detailColumns.splice(0, 2);
      detailColumns.unshift(
        {
          'columnDef': 'expandArrowHidden',
          'displayText': ''
        },
        {
          'columnDef': 'sales_model_code',
          'displayText': ''
        }
      );
      return {
        columns: detailColumns,
        rows: detail.sale_model_mix,
        template: this.analyticsDetailsTableTemplate,
        parentIndex: index,
      };
    });
  }

  // update analytics datatable with new columns, rows, expandRows based on new comparison group
  comparisonGroupChange(): void {
    const columns = this.appendRegions(analyticsColumns);
    this.filteredAnalyticsColumns = this.filterByComparisonGroup(columns);
    // need to update expandrows as well
    this.analyticsExpandRowTemplates = this.setAnalyticsExpandRows();
    this.toggleableAnalyticsColumns = this.setToggleableColumns(this.filteredAnalyticsColumns);
    this.analyticsDataSubscriber.next({
      columns: this.filteredAnalyticsColumns,
      rows: this.analyticsRowData,
      expandRows: this.analyticsExpandRowTemplates
    });
    // when child tables rerender, make sure no columns are toggled off
    this.analyticsColumnsToToggle = [];
  }

  // return the value / code for the user selected comparison group (via radio buttons)
  getComparisonGroupValue(): string {
    switch (this.suggestedOrderForm.get('comparisonGroup').value) {
      case 'region':
        return this.regionCode;
      case 'cluster':
        return this.clusterId;
      case 'area':
        return this.areaCode;
    }
  }

  // filters columns down to comparison group
  // only one comparsion group is shown at a time
  filterByComparisonGroup(columns: DataTableColumn[]): DataTableColumn[] {
    return columns.filter((column: DataTableColumn) => {
      const isComparisonValue =
        column.columnDef.includes('region') || column.columnDef.includes('area') || column.columnDef.includes('cluster');
      // if it is a comparsion group column
      if (isComparisonValue) {
        // if it is the current user selected comparison group (via radio buttons), show this column
        if (column.columnDef.includes(this.suggestedOrderForm.get('comparisonGroup').value)) {
          return column;
        }
        return;
      }
      // it is not a comparison group column, go ahead and show it
      return column;
    });
  }

  // TODO: may want to create a copy of original datasource before used by component because component mutates it
  // export analytics data source by default - if specified, export suggested orders data
  exportToExcel(isSuggestedOrders) {
    // converts a DOM TABLE element to a worksheet
    // json_to_sheet for full table data, table_to_sheet for just the data in view
    const dataToExport = isSuggestedOrders ? this.soTable.dataSource.data : this.analyticsTable.dataSource.data;
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, 'newsheet.xlsx');
  }









  getDataForCharts() {
    this.services.getChartData(this.selectedCarline.year, this.selectedCarline.code).subscribe((response: any) => {

      this.jsonChartDataMain = response.distribution_pool_trim_analysis;
      console.log('jsonChartDataMain:', this.jsonChartDataMain);

      this.jsonChartDataTrims = response.trims;
      console.log('jsonChartDataTrims:', this.jsonChartDataTrims);

      this.initChartsSection();
    });
  }

  initChartsSection = () => {
    if (!this.jsonChartDataMain) {
      return;
    }
    console.log('initChartsSection');

    // Update total volume
    this.trimChartTotalVolume = this.jsonChartDataMain.carline.total_allocation;

    this.updateMainCharts();

    this.updateTrims();
  }

  updateTrims = () => {
    console.log('updateTrims');
    // Get trim list for selected carline
    this.chartTrimList = this.jsonChartDataMain.carline.trim_mix.map((trimMixObj) => {
      return trimMixObj.trim;
    });
    this.selectedChartTrim = this.chartTrimList[0];

    this.updateSubCharts();
  }



  updateMainCharts = () => {
    console.log('updateMainCharts');

    this.initMainTrimChart();
    this.initMainDetailChart();
    this.initMainColorMixChart();
  }

  initMainTrimChart = () => {
    console.log('initMainTrimChart');
    const dataName = 'VOLUME';
    const dataLabels = [];
    const dataValues = [];
    this.mainChartTrimNames = [];
    const selectedCarlineObj = this.jsonChartDataMain.carline;
    if (selectedCarlineObj.trim_mix) {
      selectedCarlineObj.trim_mix.forEach(trimMixObj => {
        dataLabels.push(trimMixObj.trim);
        dataValues.push(trimMixObj.accepted_vol);
        this.mainChartTrimNames.push(trimMixObj.trim);
      });
    }
    const totalAllocation = selectedCarlineObj.total_allocation;
    document.querySelector('#mainTrimChart').innerHTML = '';
    const options = ChartOptionsService.getBarChartOptions(
      'mainTrimChart', 317, dataName, dataLabels, dataValues, totalAllocation, true);
    const chart = new ApexCharts(document.querySelector('#mainTrimChart'), options);
    chart.render();
  }

  initMainDetailChart = () => {
    if (this.selectedChartDetail === 'Drivetrain') {
      this.initMainDrivetrainChart();
    } else {
      this.initMainTransmissionChart();
    }
  }

  initMainDrivetrainChart = () => {
    console.log('initMainDrivetrainChart');
    const dataName = 'VOLUME';
    const dataLabels = [];
    const dataValues = [];
    this.mainChartDrivetrainNames = [];
    const selectedCarlineObj = this.jsonChartDataMain.carline;
    if (selectedCarlineObj.drivetrain_mix) {
      selectedCarlineObj.drivetrain_mix.forEach(drivetrainMixObj => {
        dataLabels.push(drivetrainMixObj.drivetrain);
        dataValues.push(drivetrainMixObj.accepted_vol);
        this.mainChartDrivetrainNames.push(drivetrainMixObj.drivetrain);
      });
    }
    const totalAllocation = selectedCarlineObj.total_allocation;
    document.querySelector('#mainDrivetrainChart').innerHTML = '';
    const options = ChartOptionsService.getBarChartOptions(
      'mainDrivetrainChart', 317, dataName, dataLabels, dataValues, totalAllocation, true);
    const chart = new ApexCharts(document.querySelector('#mainDrivetrainChart'), options);
    chart.render();
  }

  initMainTransmissionChart = () => {
    console.log('initMainTransmissionChart');
    const dataName = 'VOLUME';
    const dataLabels = [];
    const dataValues = [];
    this.mainChartTransmissionNames = [];
    const selectedCarlineObj = this.jsonChartDataMain.carline;
    if (selectedCarlineObj.transmission_mix) {
      selectedCarlineObj.transmission_mix.forEach(transmissionMixObj => {
        dataLabels.push(transmissionMixObj.transmission);
        dataValues.push(transmissionMixObj.accepted_vol);
        this.mainChartTransmissionNames.push(transmissionMixObj.transmission);
      });
    }
    const totalAllocation = selectedCarlineObj.total_allocation;
    document.querySelector('#mainTransmissionChart').innerHTML = '';
    const options = ChartOptionsService.getBarChartOptions(
      'mainTransmissionChart', 317, dataName, dataLabels, dataValues, totalAllocation, true);
    const chart = new ApexCharts(document.querySelector('#mainTransmissionChart'), options);
    chart.render();
  }

  initMainColorMixChart = () => {
    console.log('initMainColorMixChart');
    this.mainChartExtColors = [];
    const selectedCarlineObj = this.jsonChartDataMain.carline;
    const modelYear = selectedCarlineObj.model_year;
    const carlineDesc = selectedCarlineObj.carline_desc;
    let extColorMix = [] as any[];
    if (selectedCarlineObj.ext_color_mix) {
      extColorMix = selectedCarlineObj.ext_color_mix as any[];
      extColorMix.forEach(extColorMixObj => {
        this.mainChartExtColors.push({
          desc: extColorMixObj.ext_color_desc,
          img: ColorCodesService.generateImageUrl(modelYear, carlineDesc, extColorMixObj.ext_color_code),
          percent: Math.round(extColorMixObj.accepted_vol / selectedCarlineObj.total_allocation * 100)
        });
      });
    }
    document.querySelector('#mainColorMixChart').innerHTML = '';
    const options = ChartOptionsService.getColorsStackedBarChartOptions(
      'mainColorMixChart', 317, extColorMix, modelYear, carlineDesc, 'accepted_vol');
    const chart = new ApexCharts(document.querySelector('#mainColorMixChart'), options);
    chart.render();
  }



  updateSubCharts = () => {
    console.log('updateSubCharts');

    this.initSubFactoryOptionsChart();
    this.initSubDetailChart();
    this.initSubColorMixChart();
  }

  initSubFactoryOptionsChart = () => {
    console.log('initSubFactoryOptionsChart');
    const dataName = 'INSTALLATION RATE';
    const dataLabels = [];
    const dataValues = [];
    this.subChartFactoryOptionsNames = [];
    let totalAllocation = 0;
    const selectedTrimObj = this.jsonChartDataTrims.find(trimObj => {
      return trimObj.trim === this.selectedChartTrim;
    });
    if (selectedTrimObj) {
      totalAllocation = selectedTrimObj.trim_allocation;
      if (selectedTrimObj.factory_option_mix) {
        selectedTrimObj.factory_option_mix.forEach(factoryOptionMixObj => {
          dataLabels.push('[' + factoryOptionMixObj.option_code + '] ' + factoryOptionMixObj.option_desc);
          dataValues.push(factoryOptionMixObj.accepted_vol);
          this.subChartFactoryOptionsNames.push(factoryOptionMixObj.option_desc);
        });
      }
    }
    document.querySelector('#subFactoryOptionsChart').innerHTML = '';
    const options = ChartOptionsService.getBarChartOptions(
      'subFactoryOptionsChart', 317, dataName, dataLabels, dataValues, totalAllocation, true);
    const chart = new ApexCharts(document.querySelector('#subFactoryOptionsChart'), options);
    chart.render();
  }

  initSubDetailChart = () => {
    console.log('initSubDetailChart');
    if (this.selectedChartDetail === 'Drivetrain') {
      this.initSubDrivetrainChart();
    } else {
      this.initSubTransmissionChart();
    }
  }

  initSubDrivetrainChart = () => {
    console.log('initSubDrivetrainChart');
    const dataName = 'VOLUME';
    const dataLabels = [];
    const dataValues = [];
    this.subChartDrivetrainNames = [];
    let totalAllocation = 0;
    const selectedTrimObj = this.jsonChartDataTrims.find(trimObj => {
      return trimObj.trim === this.selectedChartTrim;
    });
    if (selectedTrimObj) {
      totalAllocation = selectedTrimObj.trim_allocation;
      if (selectedTrimObj.drivetrain_mix) {
        selectedTrimObj.drivetrain_mix.forEach(drivetrainMixObj => {
          dataLabels.push(drivetrainMixObj.drivetrain);
          dataValues.push(drivetrainMixObj.accepted_vol);
          this.subChartDrivetrainNames.push(drivetrainMixObj.drivetrain);
        });
      }
    }
    document.querySelector('#subDrivetrainChart').innerHTML = '';
    const options = ChartOptionsService.getBarChartOptions(
      'subDrivetrainChart', 317, dataName, dataLabels, dataValues, totalAllocation, true);
    const chart = new ApexCharts(document.querySelector('#subDrivetrainChart'), options);
    chart.render();
  }

  initSubTransmissionChart = () => {
    console.log('initSubTransmissionChart');
    const dataName = 'VOLUME';
    const dataLabels = [];
    const dataValues = [];
    this.subChartTransmissionNames = [];
    let totalAllocation = 0;
    const selectedTrimObj = this.jsonChartDataTrims.find(trimObj => {
      return trimObj.trim === this.selectedChartTrim;
    });
    if (selectedTrimObj) {
      totalAllocation = selectedTrimObj.trim_allocation;
      if (selectedTrimObj.transmission_mix) {
        selectedTrimObj.transmission_mix.forEach(transmissionMixObj => {
          dataLabels.push(transmissionMixObj.transmission);
          dataValues.push(transmissionMixObj.accepted_vol);
          this.subChartTransmissionNames.push(transmissionMixObj.transmission);
        });
      }
    }
    document.querySelector('#subTransmissionChart').innerHTML = '';
    const options = ChartOptionsService.getBarChartOptions(
      'subTransmissionChart', 317, dataName, dataLabels, dataValues, totalAllocation, true);
    const chart = new ApexCharts(document.querySelector('#subTransmissionChart'), options);
    chart.render();
  }

  initSubColorMixChart = () => {
    console.log('initSubColorMixChart');
    this.subChartExtColors = [];
    const modelYear = this.jsonChartDataMain.carline.model_year;
    const carlineDesc = this.jsonChartDataMain.carline.carline_desc;
    const selectedTrimObj = this.jsonChartDataTrims.find(trimObj => {
      return trimObj.trim === this.selectedChartTrim;
    });
    let extColorMix = [] as any[];
    if (selectedTrimObj) {
      extColorMix = selectedTrimObj.ext_color_mix as any[];
      extColorMix.forEach(extColorMixObj => {
        this.subChartExtColors.push({
          desc: extColorMixObj.ext_color_desc,
          img: ColorCodesService.generateImageUrl(modelYear, carlineDesc, extColorMixObj.ext_color_code),
          percent: Math.round(extColorMixObj.accepted_vol / selectedTrimObj.trim_allocation * 100)
        });
      });
    }
    document.querySelector('#subColorMixChart').innerHTML = '';
    const options = ChartOptionsService.getColorsStackedBarChartOptions(
      'subColorMixChart', 317, extColorMix, modelYear, carlineDesc, 'accepted_vol');
    const chart = new ApexCharts(document.querySelector('#subColorMixChart'), options);
    chart.render();
  }



  onClickCarlineDropdownOption = (newCarline: any) => {
    // console.log('onClickCarlineDropdownOption: ' + newCarlineCode);
    this.selectedCarline = newCarline;

    // Now fetch table data (and then charts data)
    this.getDataForTables();
  }

  onClickDetailDropdownOption = (newDetail: string) => {
    // console.log('onClickDetailDropdownOption: ' + newDetail);
    this.selectedChartDetail = newDetail;

    // Delay until next JavaScript cycle, otherwise html DOM has not updated yet to include chart html.
    setTimeout(() => {
      this.initMainDetailChart();
      this.initSubDetailChart();
    }, 0);
  }

  onClickTrimDropdownOption = (newTrim: string) => {
    // console.log('trimDropdownChanged: ' + newTrim);
    this.selectedChartTrim = newTrim;

    this.updateSubCharts();
  }


}

