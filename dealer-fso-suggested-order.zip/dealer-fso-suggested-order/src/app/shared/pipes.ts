import {
  Pipe,
  PipeTransform
} from '@angular/core';

@Pipe({ name: 'formatOption' })
export class FormatOptionPipe implements PipeTransform {
  transform(items: any, previewLimit: number): string {
    // should change to switch / if else if we get more options than mdo / fo
    let previewString = '';
    if (items && items.length) {
      for (let i = 0; i < items.length && i < previewLimit; i++) {
        if (!i) {
          previewString += `${items[i]}`;
        } else {
          previewString += ` | ${items[i]}`;
        }
      }
    }
    return previewString;
  }
}

@Pipe({ name: 'formatAs' })
export class FormatAs implements PipeTransform {
  transform(item: any, format: string): string {
    switch (format) {
      case 'percent':
        return `${item}%`;
    }
  }
}

@Pipe({ name: 'formatRegion' })
export class FormatRegion implements PipeTransform {
  transform(item: any, region: string): string {
    return `${item} ${region}`;
  }
}
