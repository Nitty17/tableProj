import { Component, Inject, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormArray, FormGroup, AbstractControl } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'app-form-dialog',
    styleUrls: ['./form-dialog.component.scss'],
    templateUrl: './form-dialog.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class VWDialogComponent implements OnInit {

    suggestedOrderForm: FormGroup;
    allMdoOptions: any[];
    allFactoryOptions: any[];
    selectedMdoOptions: any[];

    constructor(
        public dialogRef: MatDialogRef<VWDialogComponent>,
        private fb: FormBuilder,
        private cdRef: ChangeDetectorRef,
        @Inject(MAT_DIALOG_DATA) public data: any) {

        console.log('data is ', data);
    }

    // need this to set "selected" value when dialog is opened
    // w/o compare, angular is not showing the default selected color options
    compareFn(a: any, b: any) {
        return a && b ? a.value === b.value : a === b;
    }

    ngOnInit() {
        this.allMdoOptions = this.data.mdoOptions;
        this.allFactoryOptions = this.data.factoryOptions;
        const formData = this.formatDataForForm(this.data.formattedData);
        this.suggestedOrderForm = this.fb.group(formData);

        // subscribe to formchanges until dialog is closing
        this.suggestedOrderForm.valueChanges.pipe(takeUntil(this.dialogRef.beforeClose())).subscribe(d => {
            console.log('form changed ', this.suggestedOrderForm);
        });
        // odd well known bug w/ angular causes need for this
        // get expressionchangedaftercheck error otherwise
        // because the "select" state of the options checkboxes are already
        // checked before their value is set
        this.cdRef.detectChanges();
    }

    createSelectionArray(options: any[], isMdo: boolean) {
        const selectedOptions = [];
        this.data[`${isMdo ? 'mdoOptions' : 'factoryOptions'}`].map(availableOption => {
            // set checked property to true for already selected mdo options
            const isChecked = options.find(checkedOption => {
                return checkedOption === availableOption.option_code;
            });
            if (isChecked) { selectedOptions.push(availableOption); }
        });
        return selectedOptions;
    }

    optionValidator() {
        return (control: AbstractControl): { [key: string]: any } | null => {
            return null;
            // return { 'forbiddenCombo': { value: control.value } };
        };
    }

    doesntHaveRequiredFO(option: any) {
        let [ missingRequiredOption, hasMutuallyExclusiveOption ] = [ false, false ];
        if (option.required_factory_option) {
            const doesntHaveRequiredFactoryOption =
            this.allFactoryOptions.findIndex(factoryOption => factoryOption.option_code === option.required_factory_option);
            missingRequiredOption = doesntHaveRequiredFactoryOption === -1 ? true : false;
        }
        if (option.mutual_excluded_mdo) {
            const selected_options = this.suggestedOrderForm.get('selected_mdo_options').value;
            const doesntHaveExclusiveOption =
            selected_options.findIndex(mdoOption => mdoOption.option_code === option.mutual_excluded_mdo);
            hasMutuallyExclusiveOption = doesntHaveExclusiveOption !== -1 ? true : false;
        }
        // if doesnt have required option or has 
        return missingRequiredOption || hasMutuallyExclusiveOption;
    }

    formatDataForForm(data: any) {
        // TODO: loop through and only assign properties form cares about
        const formData = Object.assign({}, data);
        formData['available_colors'] = this.fb.array(data.available_colors);
        formData['is_new_config'] = this.fb.control(false);
        formData['change_qty'] = this.fb.control(0);
        formData['selected_mdo_options'] = [];
        if (data.mdo_options) {
            const selectedMdo = data['mdo_options'].slice(0).split(',');
            const mdoSelectionArray = this.createSelectionArray(selectedMdo, true);
            // this.selectedMdoOptions = mdoSelectionArray;
            formData['selected_mdo_options'] = this.fb.control(mdoSelectionArray, [this.optionValidator()]);
        }
        formData['selected_factory_options'] = [];
        if (data.factory_options) {
            const selectedFo = data['factory_options'].slice(0).split(',');
            const factorySelectionArray = this.createSelectionArray(selectedFo, false);
            formData['selected_factory_options'] = this.fb.control(factorySelectionArray);
        }
        return formData;
    }

    onNoClick(): void {
        this.dialogRef.close();
    }

}
