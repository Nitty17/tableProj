import { Component, Injectable, Inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { concat, merge } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class ColorDescriptionService {

    int_colors: any;
    ext_colors: any;

    constructor(private http: HttpClient) {
        const ext_colors = this.http.get('../assets/json/vw_exterior_colors.json').pipe(map(res => res));
        const int_colors = this.http.get('../assets/json/vw_interior_colors.json').pipe(map(res => res));
        merge(ext_colors, int_colors).subscribe((colors: any) => {
            if (colors.ext_colors) {
                this.ext_colors = colors.ext_colors;
            } else if (colors.int_colors) {
                this.int_colors = colors.int_colors;
            }
        });
    }

    getColorByCode(extOrInt: string, code: string) {  // returns element when provided color code found
        return this[`${extOrInt}_colors`].find(color => {
            return color[`${extOrInt}_color_code`] === code;
        });
    }

}

@Injectable()
export class FsoApiService {

    constructor(private http: HttpClient) {}

    getCarlines() {
      const carlines = this.http.get('../assets/json/carline_model_year.json').pipe(map(res => res));
      return concat(carlines);
    }
    getTableData(modelYear: number, carlineCode: string) {
      const analytics = this.http.get('../assets/json/dealer_order_analytics_new.json').pipe(map(res => res));
      const suggestedOrders = this.http.get('../assets/json/dealer_fso_suggested_orders.json').pipe(map(res => res));
      return concat(analytics, suggestedOrders);
    }
    getChartData(modelYear: number, carlineCode: string) {
      const analysis = this.http.get('../assets/json/dealer_fso_accepted_order_analysis.json').pipe(map(res => res));
      return concat(analysis);
    }
    getOptionsDescription(mdoOrFo: any[], code: string) {
        return mdoOrFo.find(option => {
            return option['option_code'] === code;
        });
    }
}

